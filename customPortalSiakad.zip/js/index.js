function loadConfig(data) {
  PortalApp.init(data);
}

const PortalApp = {
  isCivitasMode: false,
  sessionId: null,

  init: function (data) {
    this.sessionId = this._getParamVal("sessionId");
    setTimeout(function () {
      $("#body_loading").addClass("hide");
    }, 800);
    this.initEvents();
  },

  initEvents: function () {
    const self = this;

    // Smart auto-detect: watch input changes
    $("#smart_input").on("input", function () {
      const val = $(this).val();
      self.detectInputType(val);
    });

    // Login button
    $("#login_btn").on("click", function () {
      self.onLogin();
    });

    // Enter key support
    $("#smart_input, #password_input").on("keypress", function (e) {
      if (e.which === 13) self.onLogin();
    });
  },

  detectInputType: function (val) {
    // Count alphabetical characters
    const letterCount = (val.match(/[a-zA-Z]/g) || []).length;
    const wasCivitas = this.isCivitasMode;

    // If 3+ letters detected → Civitas mode (show password)
    if (letterCount >= 3) {
      this.isCivitasMode = true;
      if (!wasCivitas) {
        $("#password_wrapper").removeClass("hide");
        $("#smart_input").attr("placeholder", "Username WiFi Anda");
        $("#form_title").text("Login Civitas");
        $("#badge_icon").text("👨‍🏫");
        $("#badge_text").text("Mode: Civitas / Asatid");
        $(".login-type-badge").addClass("civitas");
        $("#password_input").focus();
      }
    } else {
      this.isCivitasMode = false;
      if (wasCivitas) {
        $("#password_wrapper").addClass("hide");
        $("#password_input").val("");
        $("#smart_input").attr("placeholder", "Masukkan NIS / Kode Voucher");
        $("#form_title").text("Login WiFi");
        $("#badge_icon").text("🔢");
        $("#badge_text").text("Mode: Santri / Tamu");
        $(".login-type-badge").removeClass("civitas");
      }
    }
  },

  onLogin: function () {
    const account = $("#smart_input").val().trim();
    const password = $("#password_input").val().trim();

    // Validate
    if (!account) {
      $("#login_msg").text("Silakan masukkan NIS, kode voucher, atau username.");
      return;
    }
    if (this.isCivitasMode && !password) {
      $("#login_msg").text("Silakan masukkan password WiFi Anda.");
      return;
    }

    $("#login_msg").text("");
    $("#login_btn").prop("disabled", true).text("Menghubungkan...");

    // Build request params
    var paramObj = {
      lang: "en_US",
      sessionId: this.sessionId,
    };

    if (this.isCivitasMode) {
      // Civitas → use fixaccount auth type
      paramObj.authType = "fixaccount";
      paramObj.account = account;
      paramObj.password = password;
    } else {
      // Santri NIS / Voucher → use voucher auth type
      paramObj.authType = "voucher";
      paramObj.account = account;
    }

    const self = this;

    $.post({
      url: "/api/auth/general",
      data: JSON.stringify(paramObj),
      contentType: "application/json",
      success: function (response) {
        if (response.success) {
          $("#login_msg").css("color", "#4ade80").text("Berhasil! Mengarahkan...");
          setTimeout(function() {
            location.href = response.result.logonUrl;
          }, 500);
        } else {
          $("#login_msg").css("color", "#ff6b6b").text(
            response.message || "NIS/Kode tidak ditemukan atau tidak aktif."
          );
          self._resetBtn();
        }
      },
      error: function () {
        $("#login_msg").css("color", "#ff6b6b").text("Gagal terhubung ke server. Coba lagi.");
        self._resetBtn();
      },
    });
  },

  _resetBtn: function() {
    $("#login_btn").prop("disabled", false).text("Hubungkan WiFi");
  },

  _getParamVal: function (paras) {
    try {
      const topUrl = decodeURI(window.top.location.href);
      const queryString = topUrl.split("?")[1];
      if (!queryString) return null;

      const paraString = queryString.split("&");
      const paraObj = {};
      for (var i = 0; i < paraString.length; i++) {
        const pair = paraString[i].split("=");
        if (pair.length === 2) {
          paraObj[pair[0].toLowerCase()] = pair[1];
        }
      }
      const returnValue = paraObj[paras.toLowerCase()];
      return returnValue !== undefined ? returnValue : null;
    } catch (e) {
      console.error("Error accessing top window URL:", e);
      return null;
    }
  },
};
